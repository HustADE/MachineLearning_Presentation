# word1 = "iamaaaa"
# word2 = "iamaaaaaa"
# a_l = ["a", "b"]
# print(" ".join(a_l))
# print(["a"] + a_l)
# # print(["a"] + "a")

# print(word1.find(word2))
# l = len(word2)
# s = word1[l:]
# print(l, s)
# # t_dict = {'a':1, "b":2}
# # for key in t_dict:
# #     print(key)

l = " "
a = "" if l=="" else " "
print(a+"1")

for i in range(1,5):
    print(i)